# PowerGuard Integration Guide

This guide provides detailed instructions for integrating the Gemma Inference SDK into the PowerGuard Android application, replacing the current server-based LLM implementation with on-device inference.

## Overview

The PowerGuard app currently uses a server-based API for device data analysis. This integration will:

1. Replace API calls with on-device Gemma-3 1B inference
2. Process device data locally using the SDK
3. Maintain the same response format and structure
4. Improve privacy and reduce network usage
5. Enable offline functionality

## Prerequisites

- PowerGuard Android application codebase
- Android Studio (Arctic Fox or later)
- Basic understanding of Kotlin, coroutines, and Hilt dependency injection

## Integration Steps

### 1. Add SDK Dependency

Add the Gemma Inference SDK to your app's `build.gradle.kts` file:

```kotlin
// App-level build.gradle.kts
dependencies {
    // Existing dependencies
    
    // Gemma Inference SDK
    implementation("com.powergaurd:gemma-inference-sdk:1.0.0")
}
```

### 2. Create SDK Provider Module

Create a new Hilt module to provide the SDK components:

```kotlin
// com/hackathon/powergaurd/di/LlmModule.kt
package com.hackathon.powergaurd.di

import android.content.Context
import com.hackathon.powergaurd.BuildConfig
import com.powergaurd.llm.GemmaConfig
import com.powergaurd.llm.GemmaInferenceSDK
import com.powergaurd.llm.LifecycleAwareSDK
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object LlmModule {
    
    @Provides
    @Singleton
    fun provideGemmaConfig(): GemmaConfig {
        return if (BuildConfig.DEBUG) {
            // Development configuration with logging
            GemmaConfig(
                modelName = "gemma-3-1b",
                enableLogging = true,
                maxTokens = 256
            )
        } else {
            // Production configuration optimized for battery
            GemmaConfig.BATTERY_EFFICIENT
        }
    }
    
    @Provides
    @Singleton
    fun provideGemmaInferenceSDK(
        @ApplicationContext context: Context,
        config: GemmaConfig
    ): GemmaInferenceSDK {
        return GemmaInferenceSDK(context, config)
    }
    
    @Provides
    @Singleton
    fun provideLifecycleAwareSDK(
        gemmaInferenceSDK: GemmaInferenceSDK
    ): LifecycleAwareSDK {
        // This automatically handles SDK lifecycle
        return LifecycleAwareSDK(gemmaInferenceSDK)
    }
}
```

### 3. Create DeviceData Converter

Create a utility class to convert the PowerGuard DeviceData model to the format expected by the SDK:

```kotlin
// com/hackathon/powergaurd/util/DeviceDataConverter.kt
package com.hackathon.powergaurd.util

import com.hackathon.powergaurd.data.model.DeviceData
import java.util.UUID

/**
 * Utility for converting PowerGuard DeviceData to a Map format for SDK consumption
 */
object DeviceDataConverter {
    
    /**
     * Converts a DeviceData object to a Map for SDK processing
     */
    fun toMap(deviceData: DeviceData): Map<String, Any> {
        val result = mutableMapOf<String, Any>()
        
        // Add device ID and timestamp
        result["deviceId"] = deviceData.deviceId
        result["timestamp"] = deviceData.timestamp
        
        // Add battery information
        result["battery"] = mapOf(
            "level" to deviceData.battery.level,
            "temperature" to deviceData.battery.temperature,
            "voltage" to deviceData.battery.voltage,
            "isCharging" to deviceData.battery.isCharging,
            "chargingType" to deviceData.battery.chargingType,
            "health" to deviceData.battery.health,
            "capacity" to deviceData.battery.capacity,
            "currentNow" to deviceData.battery.currentNow
        )
        
        // Add memory information
        result["memory"] = mapOf(
            "totalRam" to deviceData.memory.totalRam,
            "availableRam" to deviceData.memory.availableRam,
            "lowMemory" to deviceData.memory.lowMemory,
            "threshold" to deviceData.memory.threshold
        )
        
        // Add CPU information
        result["cpu"] = mapOf(
            "usage" to deviceData.cpu.usage,
            "temperature" to deviceData.cpu.temperature,
            "frequencies" to deviceData.cpu.frequencies
        )
        
        // Add network information
        result["network"] = mapOf(
            "type" to deviceData.network.type,
            "strength" to deviceData.network.strength,
            "isRoaming" to deviceData.network.isRoaming,
            "dataUsage" to mapOf(
                "foreground" to deviceData.network.dataUsage.foreground,
                "background" to deviceData.network.dataUsage.background,
                "rxBytes" to deviceData.network.dataUsage.rxBytes,
                "txBytes" to deviceData.network.dataUsage.txBytes
            ),
            "activeConnectionInfo" to deviceData.network.activeConnectionInfo,
            "linkSpeed" to deviceData.network.linkSpeed,
            "cellularGeneration" to deviceData.network.cellularGeneration
        )
        
        // Add app information
        result["apps"] = deviceData.apps.map { app ->
            mapOf(
                "packageName" to app.packageName,
                "processName" to app.processName,
                "appName" to app.appName,
                "isSystemApp" to app.isSystemApp,
                "lastUsed" to app.lastUsed,
                "foregroundTime" to app.foregroundTime,
                "backgroundTime" to app.backgroundTime,
                "batteryUsage" to app.batteryUsage,
                "dataUsage" to mapOf(
                    "foreground" to app.dataUsage.foreground,
                    "background" to app.dataUsage.background,
                    "rxBytes" to app.dataUsage.rxBytes,
                    "txBytes" to app.dataUsage.txBytes
                ),
                "memoryUsage" to app.memoryUsage,
                "cpuUsage" to app.cpuUsage,
                "notifications" to app.notifications,
                "crashes" to app.crashes,
                "versionName" to app.versionName,
                "versionCode" to app.versionCode,
                "targetSdkVersion" to app.targetSdkVersion,
                "installTime" to app.installTime,
                "updatedTime" to app.updatedTime
            )
        }
        
        // Add settings information
        result["settings"] = mapOf(
            "batteryOptimization" to deviceData.settings.batteryOptimization,
            "dataSaver" to deviceData.settings.dataSaver,
            "powerSaveMode" to deviceData.settings.powerSaveMode,
            "adaptiveBattery" to deviceData.settings.adaptiveBattery,
            "autoSync" to deviceData.settings.autoSync
        )
        
        // Add device information
        result["deviceInfo"] = mapOf(
            "manufacturer" to deviceData.deviceInfo.manufacturer,
            "model" to deviceData.deviceInfo.model,
            "osVersion" to deviceData.deviceInfo.osVersion,
            "sdkVersion" to deviceData.deviceInfo.sdkVersion,
            "screenOnTime" to deviceData.deviceInfo.screenOnTime
        )
        
        return result
    }
}
```

### 4. Create Response Converter

Create a utility class to convert SDK responses back to the PowerGuard AnalysisResponse format:

```kotlin
// com/hackathon/powergaurd/util/ResponseConverter.kt
package com.hackathon.powergaurd.util

import com.hackathon.powergaurd.data.model.AnalysisResponse
import com.hackathon.powergaurd.data.model.Actionable
import com.hackathon.powergaurd.data.model.Insight
import org.json.JSONObject
import java.util.UUID

/**
 * Utility for converting SDK responses to PowerGuard AnalysisResponse objects
 */
object ResponseConverter {
    
    /**
     * Converts a JSONObject from the SDK to an AnalysisResponse
     */
    fun toAnalysisResponse(jsonObject: JSONObject?): AnalysisResponse {
        if (jsonObject == null) {
            return createErrorResponse("Failed to generate response")
        }
        
        try {
            // Extract basic fields
            val id = jsonObject.optString("id", UUID.randomUUID().toString())
            val success = jsonObject.optBoolean("success", true)
            val timestamp = jsonObject.optDouble("timestamp", System.currentTimeMillis().toDouble())
            val message = jsonObject.optString("message", "Analysis completed")
            val responseType = jsonObject.optString("responseType", null)
            
            // Extract scores
            val batteryScore = jsonObject.optDouble("batteryScore", 50.0).toFloat()
            val dataScore = jsonObject.optDouble("dataScore", 50.0).toFloat()
            val performanceScore = jsonObject.optDouble("performanceScore", 50.0).toFloat()
            
            // Extract estimated savings
            val savingsObj = jsonObject.optJSONObject("estimatedSavings") ?: JSONObject()
            val batteryMinutes = savingsObj.optDouble("batteryMinutes", 0.0).toFloat()
            val dataMB = savingsObj.optDouble("dataMB", 0.0).toFloat()
            val estimatedSavings = AnalysisResponse.EstimatedSavings(batteryMinutes, dataMB)
            
            // Extract actionables
            val actionableArray = jsonObject.optJSONArray("actionable") ?: JSONObject().names()
            val actionables = mutableListOf<Actionable>()
            for (i in 0 until (actionableArray?.length() ?: 0)) {
                val actionObj = actionableArray?.optJSONObject(i)
                actionObj?.let {
                    actionables.add(
                        Actionable(
                            id = it.optString("id", UUID.randomUUID().toString()),
                            type = it.optString("type", "UNKNOWN"),
                            packageName = it.optString("packageName", ""),
                            description = it.optString("description", ""),
                            reason = it.optString("reason", ""),
                            newMode = it.optString("newMode", ""),
                            parameters = mapParametersFromJson(it.optJSONObject("parameters"))
                        )
                    )
                }
            }
            
            // Extract insights
            val insightsArray = jsonObject.optJSONArray("insights") ?: JSONObject().names()
            val insights = mutableListOf<Insight>()
            for (i in 0 until (insightsArray?.length() ?: 0)) {
                val insightObj = insightsArray?.optJSONObject(i)
                insightObj?.let {
                    insights.add(
                        Insight(
                            type = it.optString("type", "INFO"),
                            title = it.optString("title", ""),
                            description = it.optString("description", ""),
                            severity = it.optString("severity", "medium")
                        )
                    )
                }
            }
            
            // Create and return the AnalysisResponse
            return AnalysisResponse(
                id = id,
                success = success,
                timestamp = timestamp.toFloat(),
                message = message,
                responseType = responseType,
                actionable = actionables,
                insights = insights,
                batteryScore = batteryScore,
                dataScore = dataScore,
                performanceScore = performanceScore,
                estimatedSavings = estimatedSavings
            )
        } catch (e: Exception) {
            return createErrorResponse("Error parsing response: ${e.message}")
        }
    }
    
    /**
     * Maps a JSONObject of parameters to a Map<String, String>
     */
    private fun mapParametersFromJson(jsonObject: JSONObject?): Map<String, String> {
        if (jsonObject == null) return emptyMap()
        
        val result = mutableMapOf<String, String>()
        val keys = jsonObject.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            result[key] = jsonObject.optString(key, "")
        }
        return result
    }
    
    /**
     * Creates an error response with the given message
     */
    private fun createErrorResponse(message: String): AnalysisResponse {
        return AnalysisResponse(
            id = "error_${UUID.randomUUID()}",
            success = false,
            timestamp = System.currentTimeMillis().toFloat(),
            message = message,
            responseType = "error",
            actionable = emptyList(),
            insights = listOf(
                Insight(
                    type = "Error",
                    title = "Analysis Error",
                    description = message,
                    severity = "high"
                )
            ),
            batteryScore = 50f,
            dataScore = 50f,
            performanceScore = 50f,
            estimatedSavings = AnalysisResponse.EstimatedSavings(0f, 0f)
        )
    }
}
```

### 5. Create On-Device Repository Implementation

Create a repository implementation that uses the SDK:

```kotlin
// com/hackathon/powergaurd/data/repository/DeviceAnalysisRepository.kt
package com.hackathon.powergaurd.data.repository

import android.content.Context
import com.hackathon.powergaurd.data.model.AnalysisResponse
import com.hackathon.powergaurd.data.model.DeviceData
import com.hackathon.powergaurd.util.DeviceDataConverter
import com.hackathon.powergaurd.util.ResponseConverter
import com.powergaurd.llm.GemmaInferenceSDK
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for analyzing device data using on-device LLM inference.
 */
@Singleton
class DeviceAnalysisRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val inferenceSDK: GemmaInferenceSDK,
    private val configRepository: ConfigRepository
) {
    /**
     * Analyzes device data using on-device LLM inference.
     *
     * @param deviceData The device data to analyze
     * @return An AnalysisResponse with optimization recommendations
     */
    suspend fun analyzeDeviceData(deviceData: DeviceData): AnalysisResponse {
        return withContext(Dispatchers.IO) {
            try {
                // Check if on-device inference is enabled
                if (!configRepository.isLocalInferenceEnabled()) {
                    // Fallback to API if disabled - implement API fallback here if needed
                    return@withContext createFallbackResponse("Local inference is disabled")
                }
                
                // Convert DeviceData to Map format for SDK
                val dataMap = DeviceDataConverter.toMap(deviceData)
                
                // Initialize SDK if not already initialized
                if (!inferenceSDK.initialize()) {
                    return@withContext createFallbackResponse("Failed to initialize LLM")
                }
                
                // Generate response using SDK with the user's prompt
                val jsonResponse = inferenceSDK.generateFromData(
                    data = dataMap,
                    userGoal = deviceData.prompt,
                    maxTokens = getMaxTokensForBatteryLevel(deviceData.battery.level)
                )
                
                // Convert response to AnalysisResponse
                ResponseConverter.toAnalysisResponse(jsonResponse)
            } catch (e: Exception) {
                createFallbackResponse("Error: ${e.message}")
            }
        }
    }
    
    /**
     * Determines appropriate max tokens based on battery level.
     * Uses smaller values when battery is low to reduce processing.
     */
    private fun getMaxTokensForBatteryLevel(batteryLevel: Int): Int {
        return when {
            batteryLevel <= 15 -> 64    // Very low battery - minimal response
            batteryLevel <= 30 -> 128   // Low battery - reduced response
            else -> 256                 // Normal response size
        }
    }
    
    /**
     * Creates a fallback response when analysis fails.
     */
    private fun createFallbackResponse(message: String): AnalysisResponse {
        return ResponseConverter.toAnalysisResponse(null)
    }
}
```

### 6. Create Config Repository for Settings

Create a repository to manage SDK configuration preferences:

```kotlin
// com/hackathon/powergaurd/data/repository/ConfigRepository.kt
package com.hackathon.powergaurd.data.repository

import android.content.Context
import android.content.SharedPreferences
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for managing SDK configuration settings.
 */
@Singleton
class ConfigRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFERENCES_NAME, Context.MODE_PRIVATE
    )
    
    /**
     * Checks if local LLM inference is enabled.
     * 
     * @return true if on-device inference is enabled, false otherwise
     */
    fun isLocalInferenceEnabled(): Boolean {
        return prefs.getBoolean(KEY_LOCAL_INFERENCE_ENABLED, true)
    }
    
    /**
     * Enables or disables local LLM inference.
     * 
     * @param enabled true to enable on-device inference, false to use API
     */
    fun setLocalInferenceEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_LOCAL_INFERENCE_ENABLED, enabled).apply()
    }
    
    /**
     * Gets the maximum number of tokens for responses.
     * 
     * @return the maximum number of tokens to generate
     */
    fun getMaxResponseTokens(): Int {
        return prefs.getInt(KEY_MAX_TOKENS, 256)
    }
    
    /**
     * Sets the maximum number of tokens for responses.
     * 
     * @param maxTokens the maximum number of tokens to generate
     */
    fun setMaxResponseTokens(maxTokens: Int) {
        prefs.edit().putInt(KEY_MAX_TOKENS, maxTokens).apply()
    }
    
    companion object {
        private const val PREFERENCES_NAME = "power_guard_config"
        private const val KEY_LOCAL_INFERENCE_ENABLED = "local_inference_enabled"
        private const val KEY_MAX_TOKENS = "max_tokens"
    }
}
```

### 7. Add Settings for LLM Configuration

Add SDK configuration options to the app's settings screen:

```kotlin
// Add to settings screen
Switch(
    checked = viewModel.isLocalInferenceEnabled,
    onCheckedChange = { viewModel.setLocalInferenceEnabled(it) },
    modifier = Modifier.padding(16.dp)
)
Text(
    text = "Use On-Device Analysis",
    style = MaterialTheme.typography.bodyLarge
)
Text(
    text = "When enabled, device analysis is performed on-device without sending data to the server.",
    style = MaterialTheme.typography.bodyMedium,
    color = MaterialTheme.colorScheme.onSurfaceVariant
)
```

### 8. Initialize SDK in Application Class

Initialize the SDK in your application class:

```kotlin
// com/hackathon/powergaurd/PowerGuardApplication.kt
package com.hackathon.powergaurd

import android.app.Application
import com.powergaurd.llm.LifecycleAwareSDK
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class PowerGuardApplication : Application() {
    
    @Inject
    lateinit var lifecycleAwareSDK: LifecycleAwareSDK
    
    override fun onCreate() {
        super.onCreate()
        // No need for explicit initialization - lifecycle is managed automatically
    }
}
```

## Testing Integration

1. Add the following test to verify the integration:

```kotlin
// Test SDK integration
@Test
fun testLocalInference() = runTest {
    // Create mock data
    val deviceData = createMockDeviceData()
    
    // Initialize SDK
    val sdk = GemmaInferenceSDK(context, GemmaConfig.BATTERY_EFFICIENT)
    sdk.initialize()
    
    // Test conversion
    val dataMap = DeviceDataConverter.toMap(deviceData)
    assertNotNull(dataMap)
    
    // Test inference
    val jsonResponse = sdk.generateFromData(dataMap, "Test inference")
    assertNotNull(jsonResponse)
    
    // Test response conversion
    val analysisResponse = ResponseConverter.toAnalysisResponse(jsonResponse)
    assertNotNull(analysisResponse)
    assertTrue(analysisResponse.success)
    
    // Clean up
    sdk.shutdown()
}
```

## Performance Considerations

1. **Model Size**: The Gemma-3 1B model requires ~500MB of storage. Consider downloading it when on Wi-Fi.

2. **Memory Usage**: The model requires significant RAM. Implement checks to ensure sufficient memory is available:

```kotlin
// Check memory before running inference
private fun isMemorySufficient(): Boolean {
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val memoryInfo = ActivityManager.MemoryInfo()
    activityManager.getMemoryInfo(memoryInfo)
    
    // Require at least 500MB available
    return memoryInfo.availMem > 500 * 1024 * 1024
}
```

3. **Battery Impact**: Consider battery level before running intensive inference:

```kotlin
// Adjust token count based on battery level
private fun adjustConfigForBattery(config: GemmaConfig): GemmaConfig {
    val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val batteryLevel = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    
    return if (batteryLevel <= 15) {
        // Use minimal settings for low battery
        GemmaConfig.BATTERY_EFFICIENT.copy(maxTokens = 64)
    } else {
        config
    }
}
```

## Troubleshooting

1. **Initialization Failures**: If SDK initialization fails, check that the device has enough storage and memory.

2. **Slow Inference**: For devices with limited resources, reduce `maxTokens` and `temperature` in the configuration.

3. **Missing Responses**: If responses are missing fields, check the prompt format and ensure the model has enough tokens to generate a complete response.

4. **Memory Errors**: If your app crashes with OOM errors, implement a fallback to the API when memory is low.

## Conclusion

This integration replaces the server-based LLM API with on-device inference using Gemma-3 1B. The implementation maintains the same interface and response format while adding the benefits of privacy, offline operation, and reduced data usage. 