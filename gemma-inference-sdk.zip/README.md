# Gemma Inference SDK for Android

A lightweight and easy-to-use SDK for performing on-device LLM inference with Google's Gemma-3 models on Android devices. This SDK provides a simple API for Android developers to integrate Gemma-3 1B inference capabilities into their applications.

## Features

- Simple API for text generation with Gemma-3 1B models
- Automatic model initialization and resource management
- Built-in battery-efficient inference options
- Prompt formatting utilities
- Response parsing helpers for JSON and typed objects
- Android lifecycle integration

## Requirements

- Android SDK 24+
- Kotlin 1.5.31+
- Sufficient device storage for the model (~500MB)
- Device with adequate RAM (4GB+ recommended)

## Installation

### Gradle

Add the following to your app's build.gradle file:

```gradle
dependencies {
    implementation 'com.powergaurd:gemma-inference-sdk:1.0.0'
}
```

### Maven

```xml
<dependency>
  <groupId>com.powergaurd</groupId>
  <artifactId>gemma-inference-sdk</artifactId>
  <version>1.0.0</version>
</dependency>
```

## Basic Usage

### Initialization

```kotlin
// Create and initialize the SDK
val sdk = GemmaInferenceSDK(context)
lifecycleScope.launch {
    sdk.initialize() // Must be called in a coroutine
}

// Or with lifecycle management
val lifecycleSDK = LifecycleAwareSDK(context)
val sdk = lifecycleSDK.getSDK() // Already initialized when app enters foreground
```

### Simple Text Generation

```kotlin
// Generate text from a prompt
lifecycleScope.launch {
    val prompt = "What are the top 3 ways to save battery on an Android device?"
    val response = sdk.generateResponse(prompt)
    textView.text = response
}
```

### Custom Configuration

```kotlin
// Create SDK with custom configuration
val config = GemmaConfig(
    modelName = "gemma-3-1b",
    maxTokens = 256,
    temperature = 0.7f,
    enableLogging = true
)
val sdk = GemmaInferenceSDK(context, config)
```

### Battery-Efficient Mode

```kotlin
// Use the battery-efficient configuration
val sdk = GemmaInferenceSDK(context, GemmaConfig.BATTERY_EFFICIENT)

// Or use the efficient generation method
lifecycleScope.launch {
    val response = sdk.generateEfficientResponse(prompt)
}
```

### Generating and Parsing JSON Responses

```kotlin
lifecycleScope.launch {
    val jsonResponse = sdk.generateJsonResponse(prompt)
    jsonResponse?.let {
        val batteryScore = it.optInt("batteryScore", 0)
        val recommendations = it.optJSONArray("recommendations")
        // Process the data
    }
}
```

### Structured Data Input

```kotlin
// Create a map of device data
val deviceData = mapOf(
    "battery" to mapOf(
        "level" to 35,
        "temperature" to 38.5,
        "isCharging" to false
    ),
    "apps" to listOf(
        mapOf(
            "name" to "Social App",
            "packageName" to "com.example.social",
            "batteryUsage" to 12.5,
            "dataUsage" to 250
        ),
        mapOf(
            "name" to "Game App",
            "packageName" to "com.example.game",
            "batteryUsage" to 28.3,
            "dataUsage" to 15
        )
    )
)

// Generate response from structured data
lifecycleScope.launch {
    val userGoal = "Optimize my battery life"
    val response = sdk.generateFromData(deviceData, userGoal)
    // Process the response
}
```

### Typed Response Parsing

```kotlin
// Define a data class for the response
data class BatteryAnalysis(
    val batteryScore: Int,
    val recommendations: List<Recommendation>
) {
    data class Recommendation(
        val title: String,
        val description: String,
        val impact: String
    )
}

// Generate and parse the response
lifecycleScope.launch {
    val analysis = sdk.generateTypedResponse(prompt, BatteryAnalysis::class.java)
    analysis?.let {
        // Access the typed data
        val score = it.batteryScore
        val recommendations = it.recommendations
    }
}
```

## Integration with PowerGuard Android App

To use this SDK as a replacement for the server-based LLM:

1. Add the SDK to your project dependencies
2. Create a repository implementation that uses on-device inference:

```kotlin
class DeviceAnalysisRepository @Inject constructor(
    private val context: Context,
    private val configRepository: ConfigRepository
) {
    // Lazy initialization of SDK
    private val inferenceSDK by lazy { 
        GemmaInferenceSDK(context, GemmaConfig.BATTERY_EFFICIENT) 
    }
    
    suspend fun analyzeDeviceData(deviceData: DeviceData): AnalysisResponse {
        // Convert DeviceData to a Map for the SDK
        val dataMap = deviceDataToMap(deviceData)
        
        // Use the SDK to generate a response
        val jsonResponse = inferenceSDK.generateFromData(
            data = dataMap,
            userGoal = deviceData.prompt
        )
        
        // Convert the JSON response to AnalysisResponse
        return parseAnalysisResponse(jsonResponse)
    }
    
    // Helper methods...
}
```

## License

Apache License 2.0

## Credits

This SDK uses the LLM Inference API to provide access to Google's Gemma-3 models. 