package com.powergaurd.llm

import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Main entry point for the Gemma Inference SDK.
 * This class provides methods for on-device LLM inference using Google's Gemma models.
 */
class GemmaInferenceSDK(
    private val context: Context,
    private val config: GemmaConfig = GemmaConfig.DEFAULT
) : DefaultLifecycleObserver {
    
    private val tag = "GemmaInferenceSDK"
    private val modelManager = ModelManager(context, config)
    private val inferenceEngine = InferenceEngine(modelManager, config)
    private val responseParser = ResponseParser(config)
    private val promptFormatter = PromptFormatter()
    
    private val coroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val isInitialized = AtomicBoolean(false)
    private val _loadingState = MutableStateFlow(LoadingState.NOT_INITIALIZED)
    
    /**
     * Current loading state of the SDK
     */
    val loadingState: StateFlow<LoadingState> = _loadingState
    
    init {
        if (config.autoInitialize) {
            ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        }
    }
    
    /**
     * Initializes the SDK and loads the model.
     * This should be called before making any inference requests.
     * If autoInitialize is true in the config, this is called automatically.
     *
     * @return true if initialization was successful, false otherwise
     */
    suspend fun initialize(): Boolean {
        if (isInitialized.get()) {
            logDebug("SDK already initialized")
            return true
        }
        
        return withContext(Dispatchers.IO) {
            try {
                _loadingState.value = LoadingState.INITIALIZING
                modelManager.initialize()
                isInitialized.set(true)
                _loadingState.value = LoadingState.READY
                logDebug("SDK initialized successfully")
                true
            } catch (e: Exception) {
                logError("SDK initialization failed", e)
                _loadingState.value = LoadingState.ERROR
                false
            }
        }
    }
    
    /**
     * Asynchronously initializes the SDK in a coroutine.
     */
    fun initializeAsync() {
        coroutineScope.launch {
            initialize()
        }
    }
    
    /**
     * Generates a response for the provided prompt using the Gemma model.
     *
     * @param prompt The input prompt for the model
     * @param maxTokens Maximum number of tokens to generate
     * @param temperature Temperature parameter for controlling randomness
     * @return The raw text response from the model, or null if generation fails
     */
    suspend fun generateResponse(
        prompt: String,
        maxTokens: Int = config.maxTokens,
        temperature: Float = config.temperature
    ): String? {
        if (!ensureInitialized()) {
            return null
        }
        
        return inferenceEngine.generateText(
            prompt = prompt,
            maxTokens = maxTokens,
            temperature = temperature
        )
    }
    
    /**
     * Generates a response and attempts to parse it as a JSON object.
     *
     * @param prompt The input prompt for the model
     * @param maxTokens Maximum number of tokens to generate
     * @param temperature Temperature parameter for controlling randomness
     * @return The parsed JSONObject or null if generation/parsing fails
     */
    suspend fun generateJsonResponse(
        prompt: String,
        maxTokens: Int = config.maxTokens,
        temperature: Float = config.temperature
    ): JSONObject? {
        val response = generateResponse(prompt, maxTokens, temperature)
        return responseParser.parseJsonResponse(response)
    }
    
    /**
     * Generates a response and parses it into the specified data class.
     *
     * @param prompt The input prompt for the model
     * @param responseClass The class to parse the response into
     * @param maxTokens Maximum number of tokens to generate
     * @param temperature Temperature parameter for controlling randomness
     * @return The parsed object or null if generation/parsing fails
     */
    suspend fun <T> generateTypedResponse(
        prompt: String,
        responseClass: Class<T>,
        maxTokens: Int = config.maxTokens,
        temperature: Float = config.temperature
    ): T? {
        val response = generateResponse(prompt, maxTokens, temperature)
        return responseParser.parseTypedResponse(response, responseClass)
    }
    
    /**
     * Generates a response from a map of data, formatted using the prompt formatter.
     *
     * @param data Key-value pairs to include in the prompt
     * @param userGoal Optional user goal to include in the prompt
     * @param maxTokens Maximum number of tokens to generate
     * @param temperature Temperature parameter for controlling randomness
     * @return The parsed JSONObject or null if generation/parsing fails
     */
    suspend fun generateFromData(
        data: Map<String, Any>,
        userGoal: String? = null,
        maxTokens: Int = config.maxTokens,
        temperature: Float = config.temperature
    ): JSONObject? {
        val formattedPrompt = promptFormatter.formatMapData(data, userGoal)
        return generateJsonResponse(formattedPrompt, maxTokens, temperature)
    }
    
    /**
     * Generates a response optimized for battery efficiency.
     * Uses lower max tokens and temperature for faster inference.
     *
     * @param prompt The input prompt for the model
     * @return The raw text response, or null if generation fails
     */
    suspend fun generateEfficientResponse(prompt: String): String? {
        // Use battery-efficient settings
        return inferenceEngine.generateTextEfficient(prompt)
    }
    
    /**
     * Returns whether the device is in a low battery state.
     * Useful for deciding when to use more efficient inference options.
     */
    fun isLowBattery(): Boolean {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        return batteryManager?.let {
            val batteryLevel = it.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            batteryLevel <= LOW_BATTERY_THRESHOLD
        } ?: false
    }
    
    /**
     * Releases all resources held by the SDK.
     * Call this when the SDK is no longer needed.
     */
    fun shutdown() {
        if (isInitialized.get()) {
            logDebug("Shutting down SDK")
            coroutineScope.launch {
                modelManager.release()
                isInitialized.set(false)
                _loadingState.value = LoadingState.NOT_INITIALIZED
            }
        }
    }
    
    /**
     * Called when the app enters the foreground.
     * Initializes the model if not already initialized.
     */
    override fun onStart(owner: LifecycleOwner) {
        if (config.autoInitialize && !isInitialized.get()) {
            initializeAsync()
        }
    }
    
    /**
     * Called when the app enters the background.
     * Optionally releases resources based on configuration.
     */
    override fun onStop(owner: LifecycleOwner) {
        if (config.releaseOnBackground && isInitialized.get()) {
            shutdown()
        }
    }
    
    private suspend fun ensureInitialized(): Boolean {
        if (!isInitialized.get()) {
            logDebug("SDK not initialized, initializing now")
            return initialize()
        }
        return true
    }
    
    private fun logDebug(message: String) {
        if (config.enableLogging) {
            Log.d(tag, message)
        }
    }
    
    private fun logError(message: String, e: Exception) {
        Log.e(tag, message, e)
    }
    
    /**
     * Possible loading states for the SDK
     */
    enum class LoadingState {
        /** SDK is not initialized */
        NOT_INITIALIZED,
        
        /** SDK is currently initializing */
        INITIALIZING,
        
        /** SDK is ready for inference */
        READY,
        
        /** SDK initialization failed */
        ERROR
    }
    
    companion object {
        private const val LOW_BATTERY_THRESHOLD = 15
        
        /**
         * Returns the SDK version
         */
        @JvmStatic
        fun getVersion(): String = "1.0.0"
    }
} 