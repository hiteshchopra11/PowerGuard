package com.powergaurd.llm

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Engine for performing inference operations with the LLM model.
 * This class handles the actual generation of text responses.
 */
class InferenceEngine(
    private val modelManager: ModelManager,
    private val config: GemmaConfig
) {
    private val tag = "GemmaSDK_InferenceEngine"
    
    /**
     * Generates text based on the provided prompt.
     *
     * @param prompt The input prompt for generation
     * @param maxTokens Override the default max tokens setting (optional)
     * @param temperature Override the default temperature setting (optional)
     * @return The generated text response or null if generation fails/times out
     */
    suspend fun generateText(
        prompt: String,
        maxTokens: Int = config.maxTokens,
        temperature: Float = config.temperature
    ): String? {
        return withContext(Dispatchers.Default) {
            logDebug("Generating text for prompt: ${prompt.take(50)}...")
            
            try {
                // Use timeout to prevent long-running inference
                withTimeoutOrNull(config.timeoutMs) {
                    val model = modelManager.getModel()
                    
                    // Create a generation config
                    val generationConfig = modelManager.buildGenerationConfig().copy(
                        maxOutputTokens = maxTokens,
                        temperature = temperature
                    )
                    
                    // Generate content
                    val response = model.generateContent(
                        prompt,
                        generationConfig
                    )
                    
                    // Extract and return the text response
                    val result = response.text
                    logDebug("Generated ${result?.length ?: 0} characters of text")
                    result
                }
            } catch (e: Exception) {
                logError("Text generation failed", e)
                null
            }
        }
    }
    
    /**
     * Performs battery-efficient inference by reducing model parameters.
     * Useful for background operations or low-battery situations.
     *
     * @param prompt The input prompt for generation
     * @return The generated text response or null if generation fails/times out
     */
    suspend fun generateTextEfficient(prompt: String): String? {
        return generateText(
            prompt = prompt,
            maxTokens = config.maxTokens / 2,
            temperature = 0.1f
        )
    }
    
    private fun logDebug(message: String) {
        if (config.enableLogging) {
            Log.d(tag, message)
        }
    }
    
    private fun logError(message: String, e: Exception) {
        Log.e(tag, "$message: ${e.message}", e)
    }
} 