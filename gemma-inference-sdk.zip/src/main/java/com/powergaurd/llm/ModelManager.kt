package com.powergaurd.llm

import android.content.Context
import android.util.Log
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.GenerationConfig
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Manages the lifecycle of the LLM model, handling initialization, configuration, and cleanup.
 */
class ModelManager(
    private val context: Context,
    private val config: GemmaConfig
) {
    private val mutex = Mutex()
    private var model: GenerativeModel? = null
    private val tag = "GemmaSDK_ModelManager"
    
    /**
     * Initializes the LLM model with the provided configuration.
     * This should be called before any inference operations.
     */
    suspend fun initialize() {
        mutex.withLock {
            if (model == null) {
                logDebug("Initializing Gemma model: ${config.modelName}")
                try {
                    // Initialize the model using LLM Inference API
                    model = GenerativeModel(
                        modelName = config.modelName,
                        apiKey = null // On-device models don't need API key
                    )
                    logDebug("Model initialization successful")
                } catch (e: Exception) {
                    logError("Model initialization failed", e)
                    throw e
                }
            }
        }
    }
    
    /**
     * Retrieves the GenerativeModel instance, initializing it if necessary.
     * 
     * @return The initialized GenerativeModel instance
     * @throws IllegalStateException if model initialization fails
     */
    suspend fun getModel(): GenerativeModel {
        mutex.withLock {
            if (model == null) {
                initialize()
            }
            return requireNotNull(model) { "Model initialization failed" }
        }
    }
    
    /**
     * Builds a GenerationConfig object based on the SDK configuration.
     * 
     * @return Configuration for text generation
     */
    fun buildGenerationConfig(): GenerationConfig {
        return GenerationConfig(
            maxOutputTokens = config.maxTokens,
            temperature = config.temperature,
            topK = config.topK,
            topP = config.topP
        )
    }
    
    /**
     * Releases all resources associated with the model.
     * This should be called when the model is no longer needed.
     */
    fun release() {
        if (mutex.tryLock()) {
            try {
                logDebug("Releasing model resources")
                model = null
                // Any additional cleanup code here
            } finally {
                mutex.unlock()
            }
        }
    }
    
    private fun logDebug(message: String) {
        if (config.enableLogging) {
            Log.d(tag, message)
        }
    }
    
    private fun logError(message: String, e: Exception) {
        Log.e(tag, "$message: ${e.message}", e)
    }
} 