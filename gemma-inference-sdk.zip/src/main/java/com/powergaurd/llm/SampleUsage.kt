package com.powergaurd.llm

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Sample class demonstrating how to use the Gemma Inference SDK.
 * This is provided as a reference for integrating the SDK into applications.
 */
object SampleUsage {
    
    /**
     * Basic usage example with direct text prompt
     */
    suspend fun basicExample(context: Context): String? {
        // Create SDK instance
        val sdk = GemmaInferenceSDK(context)
        
        // Initialize the SDK
        sdk.initialize()
        
        // Create a simple prompt
        val prompt = """
            Analyze this battery data:
            - Current level: 35%
            - Temperature: 38°C
            - Is charging: false
            
            What can be done to save battery life?
        """.trimIndent()
        
        // Generate a response
        val response = sdk.generateResponse(prompt)
        
        // Clean up resources
        sdk.shutdown()
        
        return response
    }
    
    /**
     * Example using the LifecycleAwareSDK for automatic lifecycle management
     */
    fun lifecycleExample(context: Context, callback: (String?) -> Unit) {
        // Create lifecycle-aware SDK
        val lifecycleSDK = LifecycleAwareSDK(context)
        
        // Get the underlying SDK
        val sdk = lifecycleSDK.getSDK()
        
        // Launch a coroutine for async operation
        CoroutineScope(Dispatchers.Main).launch {
            // SDK is initialized automatically
            
            val prompt = "What are the top 3 ways to optimize battery life on an Android device?"
            
            // Generate the response
            val response = withContext(Dispatchers.IO) {
                sdk.generateResponse(prompt)
            }
            
            // Send result to callback
            callback(response)
            
            // No need to call shutdown as the lifecycle observer handles it
        }
    }
    
    /**
     * Example showing how to use structured data input
     */
    suspend fun deviceDataExample(context: Context, deviceData: Map<String, Any>): JSONObject? {
        val sdk = GemmaInferenceSDK(context, GemmaConfig.BATTERY_EFFICIENT)
        
        try {
            sdk.initialize()
            
            // User's goal to include in the prompt
            val userGoal = "Save my battery and reduce data usage"
            
            // Generate a response from the device data
            return sdk.generateFromData(
                data = deviceData,
                userGoal = userGoal,
                maxTokens = 256,
                temperature = 0.3f
            )
        } finally {
            sdk.shutdown()
        }
    }
    
    /**
     * Example of parsing the response into a specific data class
     */
    suspend fun typedResponseExample(context: Context): PowerGuardAnalysis? {
        val sdk = GemmaInferenceSDK(context)
        
        try {
            sdk.initialize()
            
            val prompt = """
                Create an optimization plan for a device with:
                - 25% battery remaining
                - 4 hours since last charge
                - 500MB data used today
                - Running 15 background apps
                
                Return a detailed analysis with battery and data saving recommendations.
            """.trimIndent()
            
            // Generate and parse the response directly into a data class
            return sdk.generateTypedResponse(
                prompt = prompt,
                responseClass = PowerGuardAnalysis::class.java
            )
        } finally {
            sdk.shutdown()
        }
    }
    
    /**
     * Sample data class for typed response parsing
     */
    data class PowerGuardAnalysis(
        val batteryScore: Int,
        val dataScore: Int,
        val recommendations: List<Recommendation>,
        val estimatedSavings: EstimatedSavings
    ) {
        data class Recommendation(
            val id: String,
            val title: String,
            val description: String,
            val impact: String,
            val packageName: String?
        )
        
        data class EstimatedSavings(
            val batteryMinutes: Int,
            val dataMB: Int
        )
    }
    
    /**
     * Demonstrates low-battery-friendly inference
     */
    suspend fun efficientInferenceExample(context: Context): String? {
        val sdk = GemmaInferenceSDK(context)
        
        try {
            sdk.initialize()
            
            // Check if the device is in a low battery state
            return if (sdk.isLowBattery()) {
                // Use efficient inference option
                sdk.generateEfficientResponse(
                    "Give me 3 quick tips to save battery life."
                )
            } else {
                // Use standard inference
                sdk.generateResponse(
                    "Give me 5 detailed tips to optimize battery life with explanation for each."
                )
            }
        } finally {
            sdk.shutdown()
        }
    }
} 